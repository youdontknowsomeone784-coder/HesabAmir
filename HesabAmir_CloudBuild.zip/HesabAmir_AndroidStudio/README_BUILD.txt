حساب امیر — پروژه آماده Android Studio

نحوه ساخت APK:
1. Android Studio را نصب کنید.
2. این پوشه را با Open باز کنید.
3. صبر کنید Gradle Sync تمام شود.
4. از منوی Build گزینه Build APK(s) را بزنید.
5. APK در app/build/outputs/apk/debug/ قرار می‌گیرد.

برنامه آفلاین است و HTML داخل assets بسته‌بندی شده است.
اطلاعات حسابداری در LocalStorage خود WebView ذخیره می‌شود.
